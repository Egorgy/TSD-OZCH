package ru.ozch.tsd;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class MainActivity extends Activity {
  LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();
  HashMap<String,String> names=new HashMap<>();
  LinearLayout root, rows; TextView summary, catalogStatus; EditText codeInput, qtyInput;
  String lastCode="";
  final int IMPORT=11,EXPORT=12;
  @Override public void onCreate(Bundle b){super.onCreate(b);load();draw();}
  int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
  TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(25,37,48));t.setPadding(dp(3),dp(8),dp(3),dp(8));return t;}
  Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(v->r.run());return b;}
  void draw(){ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(18),dp(18),dp(30));sc.addView(root);setContentView(sc);
    root.addView(text("ТСД ОЗЧ · Инвентаризация",24));summary=text("",18);root.addView(summary);
    catalogStatus=text("",14);root.addView(catalogStatus);
    root.addView(button("Загрузить справочник CSV / XLSX",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT);}));
    root.addView(button("СКАНИРОВАТЬ КАМЕРОЙ",()->scan()));
    root.addView(text("Код (или ввести вручную)",14));codeInput=new EditText(this);codeInput.setSingleLine(true);codeInput.setHint("Штрихкод");root.addView(codeInput);
    root.addView(text("Количество",14));qtyInput=new EditText(this);qtyInput.setInputType(2);qtyInput.setText("1");root.addView(qtyInput);
    root.addView(button("Добавить количество",()->add()));
    root.addView(button("Экспорт CSV",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"inventarizaciya_ozch.csv");startActivityForResult(i,EXPORT);}));
    root.addView(text("Собранные позиции (нажми для исправления)",18));rows=new LinearLayout(this);rows.setOrientation(1);root.addView(rows);refresh();
  }
  void scan(){new com.journeyapps.barcodescanner.IntentIntegrator(this).setDesiredBarcodeFormats(com.journeyapps.barcodescanner.IntentIntegrator.ONE_D_CODE_TYPES).setPrompt("Наведите на внутренний штрихкод 1С").setBeepEnabled(true).setOrientationLocked(true).initiateScan();}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request==IMPORT && result==RESULT_OK && data!=null){try{importCatalog(data.getData());toast("Справочник загружен: "+names.size());refresh();}catch(Exception e){toast("Ошибка справочника: "+e.getMessage());}return;}
    if(request==EXPORT && result==RESULT_OK && data!=null){try(OutputStream o=getContentResolver().openOutputStream(data.getData())){o.write(exportCsv().getBytes(StandardCharsets.UTF_8));toast("Ведомость сохранена");}catch(Exception e){toast("Ошибка экспорта: "+e.getMessage());}return;}
    com.google.zxing.integration.android.IntentResult scan=com.google.zxing.integration.android.IntentIntegrator.parseActivityResult(request,result,data);
    if(scan!=null && scan.getContents()!=null){codeInput.setText(scan.getContents());qtyInput.setText("1");qtyInput.requestFocus();toast("Считано: "+scan.getContents());}
  }
  void add(){String code=codeInput.getText().toString().trim();int q;try{q=Integer.parseInt(qtyInput.getText().toString());}catch(Exception e){toast("Введите количество");return;}if(code.isEmpty()||q<=0){toast("Нужны код и количество больше нуля");return;}counts.put(code,counts.getOrDefault(code,0)+q);lastCode=code;save();codeInput.setText("");qtyInput.setText("1");refresh();toast("Добавлено "+q+" шт.");}
  void refresh(){int sum=0;for(int n:counts.values())sum+=n;summary.setText("Позиций: "+counts.size()+"     Единиц: "+sum);catalogStatus.setText(names.isEmpty()?"Справочник не загружен — работаем по кодам":"Справочник: "+names.size()+" кодов");rows.removeAllViews();for(Map.Entry<String,Integer> e:counts.entrySet()){String code=e.getKey();String name=names.getOrDefault(code,"");TextView t=text(code+"   ·   "+e.getValue()+" шт.\n"+(name.isEmpty()?"Наименование не найдено":name),15);rows.addView(t);t.setOnClickListener(v->edit(code));}}
  void edit(String code){EditText input=new EditText(this);input.setInputType(2);input.setText(String.valueOf(counts.get(code)));new AlertDialog.Builder(this).setTitle("Количество: "+code).setMessage("Укажи итоговое количество (0 — удалить)").setView(input).setPositiveButton("Сохранить",(d,w)->{try{int q=Integer.parseInt(input.getText().toString());if(q<0)return;if(q==0)counts.remove(code);else counts.put(code,q);save();refresh();}catch(Exception ignored){toast("Неверное количество");}}).setNegativeButton("Отмена",null).show();}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  void save(){try{org.json.JSONArray a=new org.json.JSONArray();for(Map.Entry<String,Integer> e:counts.entrySet()){org.json.JSONArray x=new org.json.JSONArray();x.put(e.getKey());x.put(e.getValue());a.put(x);}getPreferences(0).edit().putString("counts",a.toString()).apply();}catch(Exception ignored){}}
  void load(){try{org.json.JSONArray a=new org.json.JSONArray(getPreferences(0).getString("counts","[]"));for(int i=0;i<a.length();i++){org.json.JSONArray x=a.getJSONArray(i);counts.put(x.getString(0),x.getInt(1));}org.json.JSONObject n=new org.json.JSONObject(getPreferences(0).getString("names","{}"));Iterator<String> it=n.keys();while(it.hasNext()){String k=it.next();names.put(k,n.getString(k));}}catch(Exception ignored){}}
  void saveNames(){org.json.JSONObject o=new org.json.JSONObject(names);getPreferences(0).edit().putString("names",o.toString()).apply();}
  String csv(String s){return "\""+s.replace("\"","\"\"")+"\"";}
  String exportCsv(){StringBuilder b=new StringBuilder("\uFEFFКод;Наименование;Количество\r\n");for(Map.Entry<String,Integer> e:counts.entrySet())b.append(csv(e.getKey())).append(';').append(csv(names.getOrDefault(e.getKey(),""))).append(';').append(e.getValue()).append("\r\n");return b.toString();}
  void importCatalog(android.net.Uri uri)throws Exception{String filename="";try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())filename=c.getString(0);}HashMap<String,String> incoming;
    try(InputStream in=getContentResolver().openInputStream(uri)){if(filename.toLowerCase().endsWith(".xlsx"))incoming=parseXlsx(in);else incoming=parseCsv(in);}
    if(incoming.isEmpty())throw new Exception("Не найдены столбцы Код/Штрихкод и Наименование");names.clear();names.putAll(incoming);saveNames();}
  HashMap<String,String> parseCsv(InputStream in)throws Exception{byte[] bytes=readAll(in);String raw=new String(bytes,StandardCharsets.UTF_8).replace("\uFEFF","");String[] lines=raw.split("\\r?\\n");HashMap<String,String> out=new HashMap<>();if(lines.length<2)return out;char sep=lines[0].contains(";")?';':',';ArrayList<String> h=splitCsv(lines[0],sep);int ci=column(h,true),ni=column(h,false);if(ci<0||ni<0)return out;for(int i=1;i<lines.length;i++){ArrayList<String> r=splitCsv(lines[i],sep);if(r.size()>Math.max(ci,ni)){String c=r.get(ci).trim(),n=r.get(ni).trim();if(!c.isEmpty())out.put(c,n);}}return out;}
  ArrayList<String> splitCsv(String s,char sep){ArrayList<String> a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char ch=s.charAt(i);if(ch=='"'){if(q&&i+1<s.length()&&s.charAt(i+1)=='"'){b.append('"');i++;}else q=!q;}else if(ch==sep&&!q){a.add(b.toString());b.setLength(0);}else b.append(ch);}a.add(b.toString());return a;}
  int column(List<String> h,boolean code){for(int i=0;i<h.size();i++){String x=h.get(i).toLowerCase(Locale.ROOT).trim();if(code&&(x.equals("код")||x.contains("штрихкод")||x.equals("barcode")))return i;if(!code&&(x.contains("наименование")||x.equals("название")||x.equals("name")))return i;}return -1;}
  byte[] readAll(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return b.toByteArray();}
  Document xml(byte[] bytes)throws Exception{DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);return f.newDocumentBuilder().parse(new ByteArrayInputStream(bytes));}
  HashMap<String,String> parseXlsx(InputStream in)throws Exception{HashMap<String,byte[]> files=new HashMap<>();try(ZipInputStream z=new ZipInputStream(in)){ZipEntry e;while((e=z.getNextEntry())!=null){if(e.getName().equals("xl/sharedStrings.xml")||e.getName().equals("xl/worksheets/sheet1.xml"))files.put(e.getName(),readAll(z));}}byte[] sheet=files.get("xl/worksheets/sheet1.xml");if(sheet==null)throw new Exception("Не найден первый лист XLSX");ArrayList<String> shared=new ArrayList<>();if(files.containsKey("xl/sharedStrings.xml")){NodeList si=xml(files.get("xl/sharedStrings.xml")).getElementsByTagName("si");for(int i=0;i<si.getLength();i++)shared.add(si.item(i).getTextContent());}NodeList rows=xml(sheet).getElementsByTagName("row");HashMap<String,String> out=new HashMap<>();int ci=-1,ni=-1;for(int i=0;i<rows.getLength();i++){NodeList cells=((Element)rows.item(i)).getElementsByTagName("c");HashMap<Integer,String> r=new HashMap<>();for(int j=0;j<cells.getLength();j++){Element c=(Element)cells.item(j);String ref=c.getAttribute("r");int col=0;for(int k=0;k<ref.length()&&Character.isLetter(ref.charAt(k));k++)col=col*26+(Character.toUpperCase(ref.charAt(k))-'A'+1);col--;String val="";NodeList v=c.getElementsByTagName("v");if(v.getLength()>0)val=v.item(0).getTextContent();else if(c.getAttribute("t").equals("inlineStr"))val=c.getTextContent();if(c.getAttribute("t").equals("s")&&!val.isEmpty())val=shared.get(Integer.parseInt(val));r.put(col,val);}if(i==0){int max=0;for(int k:r.keySet())max=Math.max(max,k);ArrayList<String> h=new ArrayList<>();for(int k=0;k<=max;k++)h.add(r.getOrDefault(k,""));ci=column(h,true);ni=column(h,false);if(ci<0||ni<0)return out;}else{String code=r.getOrDefault(ci,"").trim();if(!code.isEmpty())out.put(code,r.getOrDefault(ni,""));}}return out;}
}
